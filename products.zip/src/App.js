import logo from './logo.svg';
import Products from './Products/Products';
import './App.css';

function App() {
  return (
    <Products/>
  );
}

export default App;
